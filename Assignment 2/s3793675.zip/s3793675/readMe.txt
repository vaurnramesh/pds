Name : Varun Ramesh
Student ID : s3797675
Topic :  Activity Recognition from Single Chest-Mounted Accelerometer

Ipynb File : py_assignment2 
py_assignment takes around 5-8 mins to run completely.

Report : report_assignment2



Ppt Slides : ppt_assignment2
The audio in the slides are set to automatic in background. Please move on to the next slide for the next audio to begin. 


************

Thank you! 